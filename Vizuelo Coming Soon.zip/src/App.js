import React from 'react';
import ComingSoon from './components/ComingSoon';

function App() {
  return (
    <div className="bg-darkBlue text-white">
      <ComingSoon />
    </div>
  );
}

export default App;